package com.server;

public class ChatServer {

    public static void main(String[] args) {
	Server.start(1813);

    }
}
